class UndefinedClass {
    public static void main(String [] args)  {
        ClassThatIsNotDefined undef;
        int x;
    }
}