class A {

}

class MainClassNotFirst {

  public static void main(String[] args) {

  }

}