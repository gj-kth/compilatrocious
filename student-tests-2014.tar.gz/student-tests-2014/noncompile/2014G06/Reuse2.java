class Main {
    public static void main(String[] a) {
    }
}

class Reuse2 {
	public int reuser(boolean osquar, boolean osquar) { 
		return 0;
	}
}
