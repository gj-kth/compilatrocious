class OpMain{
	public static void main(String[] args){
		boolean b;
		b = !1 < 2;
	}
}
