//EXT:CGE
//EXT:BDJ

class WhileIWasAway {
	public static void main(String[] args) {
		new Away().orate();
	}
}

class Away{
	int w;
	public boolean orate() {
		int u;
		u = 100;
		while(u >= 0 && w) {
			System.out.println(u);
			u = u - 1;
		}
		return (!(true || !false));
	}
}
