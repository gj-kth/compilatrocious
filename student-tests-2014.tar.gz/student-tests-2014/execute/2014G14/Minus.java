class Minus {
    public static void main(String[] args) {
        int a;
        a = 10 - 5 - 5;
        System.out.println(a);
    }
}
