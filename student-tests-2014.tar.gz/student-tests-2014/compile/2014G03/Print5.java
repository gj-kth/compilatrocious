

class Print5 {
    public static void main(String[] args) {
        System.out.println(5); //"Hello World!"); 
    }
}


