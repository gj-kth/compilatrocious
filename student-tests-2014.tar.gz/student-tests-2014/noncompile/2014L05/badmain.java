class foomain {
    public static void dmain(String [] str) {
        int a;
        main main;
    }
}

class main {
}
