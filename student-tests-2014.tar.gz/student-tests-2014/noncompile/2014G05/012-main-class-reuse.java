// noncompile: Re-declaration of class 'Main'

class Main {
  public static void main(String[] args) {
  }
}

class Main {}
