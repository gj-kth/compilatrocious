class Main {
    public static void main(String [] str) {
        int i;
        x j;

        i = 5;
        System.out.println(x.plus(1));
    }
}

class x {

    public int plus(Int v) {
        return i + v;
    }

}
