package mjc.tests.wat;

class Main {
	public static void main(String[] args) {
		//Nop
	}
}

public class Wat {
}

