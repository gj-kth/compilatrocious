class Main {

    public static void main(String[] args) {
        int a;
        int c;
        Other o;
        
        boolean b;
        o = new Other();
        
        c = 4;
        b = false;
        a = o.call_with_wrong_number_of_args(c, b);
    }

    
}

class Other{
    public int call_with_wrong_number_of_args(int c, int b, int extra) {
        return c;
    }
}
