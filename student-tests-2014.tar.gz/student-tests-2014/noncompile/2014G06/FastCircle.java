class Main {
	public static void main(String[] args) {
		
	}
}

class I extends I {}
