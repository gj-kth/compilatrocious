class Main {
    public static void main(String[] args) {
    }
}

class OtherClass {
    public int foo() {
        int b;
        b = new int[0][0];

        return 4;
    }
}
