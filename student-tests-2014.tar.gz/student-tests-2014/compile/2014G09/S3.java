class S3 {
	public static void main(String[] argv) {
		int a; 
		a = 5;
		System.out.println(a);
	}
}

class Nope {
	int a;
	int b;

	public int shortName(int j) {
		return a+b;
	}
	public int aLonger_Name(int j, int k) {
		return a+b;
	}
	public int AveryLongNameThat_dosntMakeMuchSense(int v, int r, int tre) {
		return a+b;
	}
	public int AveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryveryVeryVeryLongLongVeryname(int o, int p, int q, int r) {
		return a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b*3000+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a*11+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a*3+a+a+a+a+a+b+a+a+a+a+a*5+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a+b+a+a+a+a+a+a;
	}
}

