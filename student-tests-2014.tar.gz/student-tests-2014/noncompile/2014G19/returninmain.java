class returninmain{
	public static void main(String[] args){
		return true;	
	}
}
