class snappycute {
  public static void main(String[] a) {
    int x;
    Fac f;
    Boll b;
    /*
    x = new Boll()
    System.out.println(3+7);
    */
    f = new Fac();
    b = f.ny();
    System.out.println(b.test());
    System.out.println(b.test9());
  }
}

class Fac {
  int y;

  public int frac(int k) {
    Fac a;
    int x;
    x = 3;
    return x;
  }

  public Boll ny() {
    return new Boll();
  }
}

class Boll {
  Fac a;
  Boll b;

  public int test() {
    a = new Fac();
    return a.frac(2);
  }

  public int test2() {
    int x;
    x = this.test3();
    return x;
  }

  public int test3() {
    int x;
    x = this.test4();
    return x;
  }

  public int test4() {
    int x;
    x = this.test5();
    return x;
  }

  public int test5() {
    int x;
    x = this.test6();
    return x;
  }

  public int test6() {
    int x;
    x = this.test7();
    return x;
  }

  public int test7() {
    int x;
    x = this.test8();
    return x;
  }

  public int test8() {
    return 1337;
  }

  public int test9() {
    int x;
    x = this.test2();
    a = new Fac();

    return x;
  }

  public int test10() {
    a = new Fac();
    return a.frac(2);
  }

  public int test11() {
    a = new Fac();
    return a.frac(2);
  }

  public int test12() {
    a = new Fac();
    return a.frac(2);
  }

  public int test13() {
    a = new Fac();
    return a.frac(2);
  }

  public int test14() {
    a = new Fac();
    return a.frac(2);
  }

  public int test15() {
    a = new Fac();
    return a.frac(2);
  }

  public int test16() {
    a = new Fac();
    return a.frac(2);
  }

  public int test17() {
    a = new Fac();
    return a.frac(2);
  }

  public int test18() {
    a = new Fac();
    return a.frac(2);
  }

  public int test19() {
    a = new Fac();
    return a.frac(2);
  }

  public int test20() {
    a = new Fac();
    return a.frac(2);
  }

  public int test21() {
    a = new Fac();
    return a.frac(2);
  }
}
