class LexerTestNoSpaces {
	publicstaticvoid main(String[] args) {
	}
}
