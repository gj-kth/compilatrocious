class OverloadedField {
    public static void main(String[] args) {
    }    
}

class Foo {
    int foo;
	
    public int foo() {
        int foo;
        foo = 3;
        return foo;
    }
}
