// EXT:!IWE
class IfWithoutElse {
    public static void main(String[] args) {
        if(false)
        {
            System.out.println("No!");
        }
    }
}
