/**
 * This right here is /* not allowed.*/
 *
 * @author Elvis Stansvik <elvstone@gmail.com>
 */
class NestedComments {
    public static void main(String[] args) {
    }
}
