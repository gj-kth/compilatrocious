class DoubleDeclaredClasses {
    public static void main(String[] args) {
    }
}

class DoubleDeclaredClasses {
    public int foo() {
        return 1;
    }
}
