class ReservedWordProblem {
	public static void main(String[] args){
		
	}
}

class class1 {
	int length;
	public int[] arrayAllocAndAssign() {
		int a;
		a = 32;
		return i;
	}
}
