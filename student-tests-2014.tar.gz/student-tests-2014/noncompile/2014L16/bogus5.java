
class bogus5 {

	/**
	 * param args
	 */
	public static void main() {
		// TODO Auto-generated method stub
		int MissingStuffsAbove;
		MissingStuffsAbove = 0+1;
		MissingStuffsAbove=MissingStuffsAbove+2;
		
	}

}
