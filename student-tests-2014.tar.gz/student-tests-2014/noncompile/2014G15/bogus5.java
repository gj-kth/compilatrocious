class bogus5 {
  public static void main(String[] args) {
    if (!1 < 2) {
      System.out.println(4);
    } else {
    }
  }
}
