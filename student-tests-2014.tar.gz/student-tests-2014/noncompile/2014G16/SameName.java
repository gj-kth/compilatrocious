class SameName {

  public static void main(String[] args) { }

}

class SameName { }
