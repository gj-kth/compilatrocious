class LengthMethod {
  public static void main(String[] args) {
    System.out.println(new LengthMethod().length);
  }

  public void length() {
  }
}
