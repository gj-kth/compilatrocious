class TrailingNilStatement {
  public static void main(String[] args) {
    while (true)
    if (true) while (true) else while (true)
  }
}

