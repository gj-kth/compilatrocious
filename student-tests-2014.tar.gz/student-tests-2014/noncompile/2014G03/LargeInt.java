class Integer {
    public static void main(String[] args) {
		int x;

		x = 10000000000; // should fail
    }
}
