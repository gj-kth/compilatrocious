class testmultidim {
	public static void main(String[] args) {
		int[][] mult;
		mult = new int[10][5];
	}
}

class Test {
	public int[][] test() {
		return new int[10][5];
	}
}