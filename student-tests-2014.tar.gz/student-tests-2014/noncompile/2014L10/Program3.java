class Program
{
  public static void main(String [] args)
  {
    return 2;
  }
}
