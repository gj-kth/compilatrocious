/* FET MED COMMENTS!!!!
sadasd
sa
d
sad
SA
*/


class F2 {
	public static void main(String[] argv) {
		int a; 
		Lol q;
		a = q.wat();
		a = 5 ; //must be 5!
		a = /* nope, should be three*/ 3;
		System.out.println(a);
	}
}

class Lol {
	int b;
	public int wut() {
		int r; 
		g = 4*3; //FAIL here
		
		return a;
	}
}
