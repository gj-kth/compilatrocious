class SimpleAssign {
    public static void main(String[] args) {
        int a;
        int b;
        a = 3;
        System.out.println(a);
    }
}
