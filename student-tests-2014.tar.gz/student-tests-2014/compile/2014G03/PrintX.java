

class PrintX {
    public static void main(String[] args) {
        int x;
        x = 5; 
        System.out.println(x); 
    }
}


