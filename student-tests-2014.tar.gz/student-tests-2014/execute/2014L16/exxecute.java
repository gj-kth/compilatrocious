// EXT:IWE
class exxecute {


	public static void main(String[] args) {
		boolean a;
		int[] b;
		int s ;
		int as;
		b = new int[2];
		a=true;
		as=23;
		System.out.println(b[0]);
		//s = new excute().woop(2);
s=2;
		if(as < s){
			System.out.println(s);
		}
	}
}
