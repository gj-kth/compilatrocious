class OperatorPrecedence {
  public static void main(String[] args) {
    System.out.println(5 + 3 * 2 - 1 * 4 + 3);
    System.out.println(3 + 2 - (5 - 1) * 3);
    System.out.println(1 - 2 * 5 + 1);
  }
}