This is not a comment

class Factorial{
    public static void main(String[] a){
		int x;
    }
}

class Fac {
    
    int num;
    public int ComputeFac(int num){

		return getNum();
    }
    public int getNum() {
    	return num;
    }

}
