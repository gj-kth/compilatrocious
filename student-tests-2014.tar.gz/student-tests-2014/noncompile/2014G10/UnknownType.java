class M {
    public static void main(String[] args) {
        M3 m;
        m = new M3();
    }
}

class M2 {
}
