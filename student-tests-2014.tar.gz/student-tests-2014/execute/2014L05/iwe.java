// EXT:IWE
// EXT:CGE
// EXT:CGT

class iwe {
    public static void main(String [] str) {
        int a;
        a = 5;
        if (a < 6) {
            System.out.println(1);
        }
        if (a >= 5) {
            System.out.println(1);
        }
        if (a > 5) {
            System.out.println(0);
        } else {
            System.out.println(1);
        }
    }
}
