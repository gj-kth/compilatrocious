class foomain {
    public static void main(String [] str) {
        int a;
        int [] b;
        boolean c;
        x d;

        b = new int[10];

        a = new x().hop(a,b,c,d);
    }
}

class x {

    public boolean hop(int a, int [] b, boolean c, x d) {
        return !a + 5;
    }

}
