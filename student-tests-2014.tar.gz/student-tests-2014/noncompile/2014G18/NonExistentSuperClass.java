// EXT:ISC

class Main {
	
	public static void main(String[] args){

	}

}


class Exists extends NonExistent{



}

