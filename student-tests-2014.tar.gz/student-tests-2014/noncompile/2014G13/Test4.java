//EXT:LONG

class Test4 {
	
	public static void main(String[] args){
		int[] iarr;
		long[] larr;
		int a;
		int b;
		long c;
		long d;
		
		iarr = new int[2];
		larr = new long[2];
		
		iarr[0] = 3;
		larr[0] = 3;
		iarr[1] = 7;
		larr[1] = 7;
		
		a = iarr[0];
		b = larr[0];
		c = iarr[0];
		d = larr[0];
		
	}
}

