class Main {
	public static void main(String[] args) {
		int i;

		i = i.sing(this);
	}
}
