//EXT:INT32
class IntOverflow {
    public static void main(String[] argz) {
        int abc;
        abc = 2147483648; // Too large by 1
    }
}
