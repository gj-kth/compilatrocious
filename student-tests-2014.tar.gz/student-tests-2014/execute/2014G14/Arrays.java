class Arrays {
    public static void main(String[] args) {
        int[] a;
        a = new int[10];
        a[0] = 1;
        System.out.println(a[0]);
    }
}
