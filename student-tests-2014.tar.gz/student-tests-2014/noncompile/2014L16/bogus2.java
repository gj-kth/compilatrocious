
class bogus2 {

	

	
	/**
	 * param args
	 */
	public static void main(String[] args) {
		boolean a;
		a = a();
	}

}

class bt{
	private int a(){
		return 1;
	}
}