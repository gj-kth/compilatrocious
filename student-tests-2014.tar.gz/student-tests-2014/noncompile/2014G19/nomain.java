class nomain{
	
}