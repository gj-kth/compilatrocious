class NoTypeDeclared {
    public static void main(String[] args) {
        i = 3;
    }
}
