// EXT:SPILL

class Main {
	public static void main(String[] s) {
		A v1;
		A v2;
		A v3;
		A v4;
		A v5;
		A v6;
		A v7;
		A v8;
		A v9;
		A v10;
		A v11;
		A v12;
		A v13;
		A v14;
		A v15;
		A v16;
		A v17;
		A v18;
		A v19;
		A v20;
		A v21;
		A v22;
		A v23;
		A v24;
		A v25;
		A v26;
		A v27;
		A v28;
		A v29;
		A v30;
		A v31;
		A v32;
		A v33;
		A v34;
		A v35;

		v1 = (new A()).init(2);
		v2 = (new A()).init(2);
		v3 = (new A()).init(2);
		v4 = (new A()).init(2);
		v5 = (new A()).init(2);
		v6 = (new A()).init(2);
		v7 = (new A()).init(2);
		v8 = (new A()).init(2);
		v9 = (new A()).init(2);
		v10 = (new A()).init(2);
		v11 = (new A()).init(2);
		v12 = (new A()).init(2);
		v13 = (new A()).init(2);
		v14 = (new A()).init(2);
		v15 = (new A()).init(2);
		v16 = (new A()).init(2);
		v17 = (new A()).init(2);
		v18 = (new A()).init(2);
		v19 = (new A()).init(2);
		v20 = (new A()).init(2);
		v21 = (new A()).init(2);
		v22 = (new A()).init(2);
		v23 = (new A()).init(2);
		v24 = (new A()).init(2);
		v25 = (new A()).init(2);
		v26 = (new A()).init(2);
		v27 = (new A()).init(2);
		v28 = (new A()).init(2);
		v29 = (new A()).init(2);
		v30 = (new A()).init(2);
		v31 = (new A()).init(2);
		v32 = (new A()).init(2);
		v33 = (new A()).init(2);
		v34 = (new A()).init(2);
		v35 = (new A()).init(2);
		System.out.println(
			v1.a()
		 +v2.a()
		 +v3.a()
		 +v4.a()
		 +v5.a()
		 +v6.a()
		 +v7.a()
		 +v8.a()
		 +v9.a()
		 +v10.a()
		 +v11.a()
		 +v12.a()
		 +v13.a()
		 +v14.a()
		 +v15.a()
		 +v16.a()
		 +v17.a()
		 +v18.a()
		 +v19.a()
		 +v20.a()
		 +v21.a()
		 +v22.a()
		 +v23.a()
		 +v24.a()
		 +v25.a()
		 +v26.a()
		 +v27.a()
		 +v28.a()
		 +v29.a()
		 +v30.a()
		 +v31.a()
		 +v32.a()
		 +v33.a()
		 +v34.a()
		 +v35.a());
	}
}

class A {
	int a;
	public A init(int n) {
		a = n;
		return this;
	}
	public int a() {
		return a;
	}
}