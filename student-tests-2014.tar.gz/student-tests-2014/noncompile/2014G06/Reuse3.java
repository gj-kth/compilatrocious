class Main {
    public static void main(String[] args){
    }
}

class Reuse3 {
	public boolean reuser(boolean osquar) {
		int osquar;
		return osquar;
	}
}
