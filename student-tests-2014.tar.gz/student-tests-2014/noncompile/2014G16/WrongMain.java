class WrongMain {
  public static void iamnotmain(String[] args) {
  }
}
