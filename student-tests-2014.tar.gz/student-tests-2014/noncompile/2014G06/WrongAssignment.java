class Main {
	public static void main(String[] args) {
		Main m;
		NotMain nm;

		m = new Main();

		nm = m;
	}
}

class NotMain {}
