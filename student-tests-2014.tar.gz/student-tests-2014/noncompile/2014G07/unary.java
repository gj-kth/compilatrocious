//EXT:INT32
class Unary {
    public static void main(String[] argz) {
        int abc;
        abc = -1; //Unary minus
    }
}
