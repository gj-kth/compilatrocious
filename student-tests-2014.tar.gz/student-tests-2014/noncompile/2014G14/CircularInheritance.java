// EXT:ISC

class CircularInheritance {
    public static void main(String[] args)
    {
    }
}

class A extends C {
}

class B extends A {
}

class C extends B {
}
