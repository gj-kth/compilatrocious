class SameMethodAndVariableName {
    public static void main(String[] args) {
    }
}

class Foo {
    int foo;

    public int foo() {
        return 1;
    }
}
