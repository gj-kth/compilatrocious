class F3 {
	public static void main(String[] argv) {
		int a; 
		System.out.println(a);
	}
}

//Unused class, should not pass
class Lol {
	int b;
	public boolean wut() {
		int r; 
		b = 4*3; 
		
		return b; //return int from boolean
	}
}
