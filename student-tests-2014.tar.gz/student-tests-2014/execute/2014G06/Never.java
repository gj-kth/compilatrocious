class Main {
	public static void main(String[] args) {
		if (6 < 5)
			System.out.println(0);
		else {}

		if (5 < 5)
			System.out.println(1);
		else {}

		if (5 < 6)
			System.out.println(2);
		else {}
	}
}
