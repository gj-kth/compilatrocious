class Main{
	public static void main(String[] args){
		Och och;
		int tuta;
		och = new Och();
		tuta = och.kör();
	}
}

class Och{
	public int kör(){
		return 0;
	}
}