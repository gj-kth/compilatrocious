class IfWithEmptyBranches {
    public static void main(String[] args) {
        if(true) { } else { }
    }
}
