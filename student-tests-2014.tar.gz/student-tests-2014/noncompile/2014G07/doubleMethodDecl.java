	
	class PasisSuperKlass {
  public static void main(String[] argz) {

  }
}
class WtfClass {
	public int Peter(int xzz) {
		System.out.println(xzz);
		return xzz+1;
	}
	public int Peter(int abc) {
		System.out.println(xzz);
		return xzz+1;
	}
}
class WtfClaxss {
	public int Peter(int xzz) {
		System.out.println(xzz);
		return xzz+1;
	}
}
