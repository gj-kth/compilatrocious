class SpacesBetweenAnd {
	public static void main(String[] args) {
		boolean res;
		res = true & & false;
		System.out.println(res);
	}
}
