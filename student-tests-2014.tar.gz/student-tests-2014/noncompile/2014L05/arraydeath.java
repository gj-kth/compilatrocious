class foomain {
    public static void main(String [] str) {
        int [] b;
        boolean c;

        c = false;
        b = new int[10];

        b[b] = 3;
    }
}
