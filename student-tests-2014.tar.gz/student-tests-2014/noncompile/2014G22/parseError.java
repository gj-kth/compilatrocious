class Factorial{
    public static void main(String[] a){
	   T test;
	   boolean hej = false;
	   test = new T();
	   System.out.println(test.ComputeFac(2));

    }
}

class T {
    
    int num;
    public int ComputeFac(int num){
		return num + getNum();
    }

    public int getNum() {
    	return num;
    }

}
