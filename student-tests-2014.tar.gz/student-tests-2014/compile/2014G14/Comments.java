/**
 * JavaDoc goes here.
 *
 * @author Martin Barksten & Victor Koronen
 */
class Comments {
    /**
     * More JavaDoc.
     */
    public static void main(String[] args) {
        // A comment on a separate line
        int a; // A comment after a vardecl
        a = 1;
        a = (a) + 3;
        System.out.println(a);
    }
}
