class PasisSuperKlass {
  public static void main(String[] argz) {

  }
}

class WtfClass {

}
class WtfClass {

}
