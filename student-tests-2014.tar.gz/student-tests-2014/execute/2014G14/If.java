class If {
	public static void main(String[] args) {
		if(true) {
			System.out.println(1);
		} else {
			System.out.println(2);
		}

		if(false) {
			System.out.println(1);
		} else {
			System.out.println(2);
		}

		if(true && false) {
			System.out.println(1);
		} else {
			System.out.println(2);
		}
	}
}
