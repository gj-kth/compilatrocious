class Main {
	public static void main(String[] args) {
		// MainLocalReuse.java:6: foo is already defined in main(java.lang.String[])
		boolean osquar;
		boolean osquar;
	}
}
