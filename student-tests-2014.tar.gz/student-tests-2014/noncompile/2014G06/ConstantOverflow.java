class Main {
	public static void main(String[] args) {
		int x;
		x = 30000000000;
	}
}
