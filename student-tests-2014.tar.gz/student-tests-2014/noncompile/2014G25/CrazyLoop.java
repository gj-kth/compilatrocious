//EXT:BDJ
class CrazyLoop {
	public static void main(String[] args) {
		while(true == true && (false == false || false == true) && true == false) {
			true = false;
			false = true;
		}
	}
}
