class EvilNames {
    public static void main(String[] args) {
        int invokevirtual;
    }
}

class istore {
    int lcmp;
    int fstore;

    public istore ifeq(istore invokespecial) {
        istore i;
        i = new istore();

        return invokespecial;
    }
}

class lcmp {
    int lcmp;
}
