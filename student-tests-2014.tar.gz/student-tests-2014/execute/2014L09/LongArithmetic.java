// EXT:LONG
class LongArithmetic {
  public static void main(String[] args) {
    System.out.println(23L * 14L + 2l > 3l);
  }
}
