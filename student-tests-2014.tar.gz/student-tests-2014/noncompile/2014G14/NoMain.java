class NoMain {
    public static void foobar(String[] args) {
    }
}
