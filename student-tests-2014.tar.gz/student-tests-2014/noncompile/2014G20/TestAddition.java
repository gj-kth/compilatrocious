class TestAddition {
	public static void main(String[] args) {
		int add;
		boolean hej;
		hej = true;
		add = 1 + 2 + 3 + 4 + 5 + hej;
	}
}
