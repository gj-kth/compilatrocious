class LessThan {
    public static void main(String[] args) {
        boolean a;
        boolean b;
        a = 1 < 2;
        b = 3 < 2;

        if(a) {
            System.out.println(1);
        } else {
            System.out.println(2);
        }

        if(b) {
            System.out.println(1);
        } else {
            System.out.println(2);
        }
    }
}
