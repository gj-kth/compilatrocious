class SimpleIfEquality {
    public static void main(String[] args) {
        if(false) {
            System.out.println(1);
        } else {
            System.out.println(2);
        }
    }
}
