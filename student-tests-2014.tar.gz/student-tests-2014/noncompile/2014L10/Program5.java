class Program
{
  public static void main(String [] wwwwwwwwwwwwwwweeeeeeeeaaaaaaaaooooooooooooooooooo)
  {
    int xyz;
    if(xyz < 2)
    {
      xyz = !false;
    }
    else {}
  }
}
