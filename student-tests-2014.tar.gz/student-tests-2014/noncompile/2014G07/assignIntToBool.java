class Main {
    public static void main(String[] args) {
        boolean t;
        t = 6;
    }
}
