// EXT:ISC

class Main {
	public static void main(String[] args){

	}
}

class You extends Spin {

}

class Spin extends My {

}

class My extends Head {

} 

class Head extends Right {

} 

class Right extends Round {

}

class Round extends Right{

}