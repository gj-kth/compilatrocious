// EXT:!ABC
class Factorial {
    public static void main(String [] str) {
        int [] a;
        int b;

        a = new int[10];
        b = 14;
        a[b] = 2;
        System.out.println(a[b]);
    }
}
