class Main {
	public static void main(String[] argv) {
	}
}

class Bad {
	public Bad test() {
		return 0;
	}
}
