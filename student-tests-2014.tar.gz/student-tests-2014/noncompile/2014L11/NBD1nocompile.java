// EXT:NBD
//
class Main {
	public static void main(String[] s) {
		int a;
		{
			int a;
		}
		if (true) {
			int a;
		}
	}
}