class Main {
	public static void main (String[] args) {
		int a;
		int b;
		a = 13;
		b = 37;
		while (a+b) {}
	}
}
