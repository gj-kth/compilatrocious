class bogus3 {
  public static void main(String[] args) {
    int[] arr;
    arr = new int[4];
    System.out.println(arr.length.length);
  }
}
