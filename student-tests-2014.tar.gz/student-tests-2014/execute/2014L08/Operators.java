class Operators {
	public static void main(String[] args) {
		int val;
		val = 100 - 9 - 8 - 7 - 6 - 5;
		System.out.println(val); // 65
		val = 54 * 6 + (2 * 532 + 5 * 6 * 2 * 2) - 16 * 17 + (18 - (19 * (21 + 43) * 53)) * 12 - 53 * 42;
		System.out.println(val); // -774150
	}
}