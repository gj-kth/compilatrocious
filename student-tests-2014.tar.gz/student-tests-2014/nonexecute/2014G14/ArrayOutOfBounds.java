class ArrayOutOfBounds {
	public static void main(String[] args) {
		int[] a;
		a = new int[1];
		a[2] = 3;
	}
}
