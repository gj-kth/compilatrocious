class missingreturn {
	public static void main(String[] args) {
		
	}
}

class class2 {
	public int method1(){
		int i;
	}
}