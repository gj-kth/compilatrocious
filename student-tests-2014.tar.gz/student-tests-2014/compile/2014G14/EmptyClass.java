class EmptyClass {
    public static void main(String[] args) {
        OtherClass c;
        c = new OtherClass();
    }
}

class OtherClass {
}
