/* FET MED COMMENTS!!!!
sadasd
sa
d
sad
SA
*/


//This is our second test case
class S2 {
	public static void main(String[] argv) {
		boolean main;
		int a; 
		a = 5 ; //must be 5!
		a = /* nope, should be three*/ 3;
		System.out.println(a);
	}
}
