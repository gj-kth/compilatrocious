// noncompile: '0 '

class Main {
  public static void main(String[] args) {
    int a;
    // Only `0` or starting with a non-zero digit is allowed.
    a = 00;
  }
}
