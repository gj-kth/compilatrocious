class Factorial {
    public static void main(String [] str) {
        int [] a;

        a = new int[10];
        System.out.println(a.length);
        a[0] = 35;
        a[1] = 10;
        System.out.println(a[0]);
        System.out.println(a[1]);
    }
}
