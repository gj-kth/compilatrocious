class testdupclassdef {
	public static void main(String[] args) {
	}
}
class testdupclassdef {
	public int test(int a) {
		return a;
	}
}
