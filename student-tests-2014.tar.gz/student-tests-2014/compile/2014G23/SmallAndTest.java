class SmallAnd {
    public static void main(String[] a) {
        if((1 < 2) && false) {
            System.out.println(1);
        } else {
            System.out.println(1);
        }

        if(1 < 2 && false) {
            System.out.println(1);
        } else {
            System.out.println(1);
        }
    }
}
