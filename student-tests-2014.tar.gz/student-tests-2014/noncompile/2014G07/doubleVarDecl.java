class Bacon {
    public static void main(String[] args) {
        int t;
        int t;
        t = 5;
    }
}