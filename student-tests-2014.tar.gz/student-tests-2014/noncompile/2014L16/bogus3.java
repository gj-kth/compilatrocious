
class bogus3 {

	/**
	 * param args
	 */
	public static void main(String[] args) {
		int a;
		a=3;
		int b = 2;
		boolean c = a+b;
		int d =c+a;
	}

}
