class MiniJavaTest1 {
    public static void naim(String[] args) {

    }
}