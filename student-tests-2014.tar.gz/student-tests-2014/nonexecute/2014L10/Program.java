// EXT:ABC
class Program
{
  public static void main(String [] args)
  {
    int [] arr;
    arr = new int[10];
    System.out.println(arr[15]);
  }
}
