class Add {
  public static void main(String[] args) {
    int a;
    int b;
    int c;

    a = 1;
    b = 2;

    c = a + b;

    System.out.println(c);
  }
}