
class Test1 {
	
	public static void main(String[] args){
		int a;
		int b;
		a = 7;
		b = 8;
		int c;
		c = a+b;
		System.out.println(c);
	}
	
}

