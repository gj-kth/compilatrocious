import java.util.HashSet;

class Main {
	public static void main(String[] args) {
		HashSet set;

		set = new HashSet();
	}
}
