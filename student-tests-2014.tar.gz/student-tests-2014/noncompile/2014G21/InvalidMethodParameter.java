class InvalidMethodParameter {
	public static void main(String[] args){
		
	}
}

class class2 {
	public int method1(int b, boolean b){
		int i;
		i = b;
		return i;
	}
}