class inlineclass {
	public static void main(String[] args){
		
	}
}

class class1 {
	class class2 {

	}
}