// EXT:ISC

class main {
    public static void main(String[] args) {
        A a;
        a = new B();
        System.out.println(a.f());
        System.out.println(a.h());
    }
}

class A{
	public int f(){
		return 1;
	}

	public int g(){
		return 2;
	}
}

class B extends A{
	public int h(){
		return 3;
	}
}
