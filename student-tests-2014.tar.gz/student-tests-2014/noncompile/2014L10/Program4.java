class Program
{
  public static void main(String [] args)
  {
    int x;
    x = x.length;
  }
}
