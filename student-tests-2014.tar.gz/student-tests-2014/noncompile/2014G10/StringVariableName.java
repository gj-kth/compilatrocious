class String {
    public static void main(String[] args) {
        int String;
        String = 1;
        System.out.println(String);
    }
}
