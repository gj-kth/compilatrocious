class test {
  public static void main(String[] grizzly) {
	System.out.println(moo);
  }
}
class moo {}

