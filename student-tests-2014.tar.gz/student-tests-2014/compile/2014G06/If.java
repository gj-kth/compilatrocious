// EXT:IWE

class Main {
	public static void main(String[] args) {
		// Supports IWE?
		if (true) {
			System.out.println(true);
		}
	}
}
