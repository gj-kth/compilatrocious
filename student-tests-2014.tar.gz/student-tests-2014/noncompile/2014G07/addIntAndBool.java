class Main {
    public static void main(String[] args) {
        boolean t;
        t = (5+8+6+1+2) < (25*5-4+false);
    }
}
