class MiniJavaTest1 {
    public static void main(String[] args) {

    }
}

class MiniJavaTest2 {
    public boolean stuff() {

    }
}