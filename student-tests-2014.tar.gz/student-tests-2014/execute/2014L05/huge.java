/*
  Have Fun With Functions! [tm]
 */

class funfun {
    public static void main(String [] str) {
        int i;
        i = 0 - 649234;
        i = i + 324617;
        i = i + 324617;
        i = i - 65536;
        i = i - 65537;
        i = i + 2 * 65536;
        System.out.println(i);

        i = 649234;
        i = i - 324617;
        i = i - 324617;
        i = i + 65536;
        i = i + 65537;
        i = i - 2 * 65536;
        System.out.println(i);
    }
}
