class func_illegal_return {
    public static void main (String [] args) {
    }
}

class b{
	public int func() {
        return;
    }
}
