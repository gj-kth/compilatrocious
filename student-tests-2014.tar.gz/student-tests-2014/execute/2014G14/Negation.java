class Negation {
    public static void main(String[] args) {
        if(!true) {
            System.out.println(1);
        } else {
            System.out.println(2);
        }
    }
}
