class invalidoperators3{
	public static void main(String [] args){
		int i;
		i = 1 << 1;
	}
}
