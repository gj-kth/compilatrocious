class UndefinedTypeInFormal {	
    public static void main(String[] args) {
    }
}

class Foo {
    int foo;

    public int bar(Double foo) {
        return 1;
    }
}
