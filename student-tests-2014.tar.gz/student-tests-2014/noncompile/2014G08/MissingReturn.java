/**
 * Check that method without return is not accepted.
 *
 * @author Elvis Stansvik <elvstone@gmail.com>
 */
class MissingReturn {
    public static void main(String[] args) {
    }
}
class MissingReturnTest {
    public int foo() {
    }
}
