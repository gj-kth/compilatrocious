
class bogus4 {
int a;
	/**
	 * param args
	 */
	public static void main(String[] args) {
		bt4 bt = new bt4();
		bt(true,21);
		
	}
	
}

class bt4{
	public int test(int a, boolean b){
		return a;
	}
	
}