class WrongType6 {
    public static void main(String[] args) {
        Main m;
        m = new OtherClass();
    }
}

class OtherClass {
}
