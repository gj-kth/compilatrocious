class Hello
{
  public static void main(String [] args)
  {
    int [] arr;
    A a;

    arr = new int[2];
    a = new A();
  }
}

class A {}
class B {}
class C {}
