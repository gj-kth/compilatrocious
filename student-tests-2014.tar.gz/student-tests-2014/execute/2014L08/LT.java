class LT {
	public static void main(String[] args) {
		int q;
		int a;
		boolean r;
		int b;
		q = 5;
		a = 3;
		b = 4;
		r =
			!(a < (b + b));
		System.out.println(3 < 4);
		System.out.println(r);
		System.out.println(b);
	}
}
