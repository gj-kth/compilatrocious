class F4 {
	public static void main(String[] argv) {
		Lol l;
		l = new  Lol();
		int a;
		System.out.println(a);
	}
}

class Lol {
	int b;
	public int wut() {
		int r; 
		b = 4*3; 
		
		return b; //return int from boolean
	}
}
