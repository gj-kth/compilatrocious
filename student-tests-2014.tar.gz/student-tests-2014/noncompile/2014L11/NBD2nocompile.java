// EXT:NBD
//
class Main {
	public static void main(String[] s) {
		int a;
		{
			boolean b;
			b = true;
		}
		if (b) {
			int b;
		}
	}
}