class foomain {
    public static void main(String [] str) {
        int a;

        a = new x().hop();
    }
}

class x {

    public int hop() {
        boolean b;

        return b;
    }
}
