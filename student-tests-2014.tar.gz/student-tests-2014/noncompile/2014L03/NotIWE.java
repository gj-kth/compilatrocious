// EXT:!IWE 

class Main
{
	public static void main(String[] argu) 
	{
		int a;
		int b;
		int c;
		
		a = 1;
		b = 2;
		c = 123;
		
		if (a < b) {
			System.out.println(c);
		}
	}
}

