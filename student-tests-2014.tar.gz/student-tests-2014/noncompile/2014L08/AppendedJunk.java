class AppendedJunk {
	public static void main(String[] args) {
	}
}
class AJ {};
