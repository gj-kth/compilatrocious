class UndeclaredIdent {
    public static void main(String[] argz) {
        abc = 1; // Never initialized
    }
}