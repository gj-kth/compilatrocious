// noncompile: Main method must be named main

class Main {
  // Wrong name on `main`
  public static void main_(String[] args) { }
}
