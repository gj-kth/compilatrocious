// EXT:NBD

class varbl {
    public static void main(String [] str) {
        int c;

        c = 0;
        {
            int d;
            d = 1;
            System.out.println(d);
        }
        System.out.println(c);
    }
}
