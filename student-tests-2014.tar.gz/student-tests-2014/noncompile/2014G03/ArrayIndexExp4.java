class Array {
    public static void main(String[] args) {
		int[] x;
		int y;

		x = new int[10 + 0.4];
		x[1] = 0; 
    }
}
