class F6 {
	public static void main(String[] args){
		
	}
}

class class1 {
	int[] i;
	public int[] arrayAllocAndAssign() {
		boolean a;
		i = new int[3*3-5+33];
		i[5] = a;
		return i;
	}
}
