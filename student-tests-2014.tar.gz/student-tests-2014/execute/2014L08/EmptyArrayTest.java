class EmptyArrayTest {
	public static void main(String[] args) {
		int[] arr;
		arr = new int[0];
		System.out.println(arr.length);
	}
}
