class Main {
	public static void main(String[] s) {
	}
}
class A {
	public boolean A() {
		return 1;
	}
}
class B {
	public A A() {
		return this;
	}
}