class Factorial {
    public static void main(String [] a) {
        int a;
        a = new Testfok().test();
        System.out.println(a);
    }
}

class Test {
    public int test() {
        System.out.println(4);
        return 5;
    }
}
