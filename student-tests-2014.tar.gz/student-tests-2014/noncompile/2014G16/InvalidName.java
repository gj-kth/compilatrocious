class MainMethod {
  public static void main(String[] args) {
  }
}

class A {
  public int 1336method() {
    return 5;
  }
}
