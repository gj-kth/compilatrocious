class __asedrftgyh {
	public/* public */static void main(String[] args) {

		int                   [                                                          ] space;
		int[               ] space2;
		int[]                       space3;
		int[                                                                             ]space4;

		Try t;
		int integer;
		boolean bool;
		{

			t = new Try();
			bool = t.init();
			integer = t.computations();

			bool = t.init();
			integer = t.computations();
			System.out.println(t.set(2));
		}

	}
}

class Try {
	int i;

	public boolean init() {
		i = 1215;
		return true;
	}

	public int computations() {
		boolean b;
		
		b = true;
		i = i+i * (((((((((((i+2)*2)+1)-1)+2))*8))+2))) - 4;
		
		if (i<5 && i      < 5 && b) {
			i = i+5*5-1+2+32+5+5+5+5+5+5+5+5*5;
		} else {
			i = 2;
		}

		{
			{
				i = 0;
				{
					System.out.println(i);
				}
				i = 1;
				System.out.println(i);
			}
			
			i = 2;
			System.out.println(i);
		}
		
		i = 3;
		System.out.println(i);

		return i;
	}

	public int get() {
		return i;
	}

	public int set(int ii) {
		i = ii;
		return i;
	}

}
