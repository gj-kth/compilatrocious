class main {
    public static void main (String [] args) {
    }
}
class other {
    int func (String [] args) {
        int a;
        return 1;
    }
}
