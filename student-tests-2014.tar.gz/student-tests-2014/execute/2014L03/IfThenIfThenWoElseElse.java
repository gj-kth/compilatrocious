// EXT:IWE
// EXT:CGT
// EXT:CEQ

class Main {
	public static void main(String[] args) {
		
		int a;
		int b;
		int c;
		
		a = 2;
		b = 1;
		
		if (a > b) {
			
			if (a == 2) {
				c = 123;
				System.out.println(c);
			}
			
		} else {
			c = 0 - 1;
			System.out.println(c);
		}
	}
}

