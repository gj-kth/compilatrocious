class WrongType5 {
    public static void main(String[] args) {
	    Main m;
	    m = 3;
    }
}
