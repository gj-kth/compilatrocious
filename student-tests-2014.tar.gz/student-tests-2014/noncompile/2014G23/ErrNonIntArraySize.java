/* Test to make sure that array size is of type integer */

class Test {
    public static void main(String[] args) {
        boolean b;
        int[] ia;
        ia = new int[b];
        System.out.println(ia[0]);
    }
}
