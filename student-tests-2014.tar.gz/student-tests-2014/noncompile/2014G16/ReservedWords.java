class ReservedWords {

  public static void main(String[] args) {
    boolean boolean;
    int int;
  }

}