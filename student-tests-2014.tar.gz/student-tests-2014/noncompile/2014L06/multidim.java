class MiniJavaTest1 {
    public static void main(String[] args) {
        int a;
        a = new int[4][7];
    }
}