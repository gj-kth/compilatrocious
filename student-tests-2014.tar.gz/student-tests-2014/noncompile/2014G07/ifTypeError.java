class test {
  public static void main(String[] grizzly) {
	int out;
	out = 5;
	if (out) {
		out = 2;
	} else {
		out = 3;
	}
  }
}
