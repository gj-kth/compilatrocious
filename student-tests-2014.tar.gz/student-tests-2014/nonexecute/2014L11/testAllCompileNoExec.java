// EXT:ABC

class Main {
	public static void main(String[] s) {
		int[] a;
		a = new int[1];
		a[0-1] = a[1];
	}
}