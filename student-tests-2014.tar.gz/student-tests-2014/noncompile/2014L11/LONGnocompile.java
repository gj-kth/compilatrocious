// EXT:LONG
//
class Main {
	public static void main(String[] s) {
		long l1;
		long l2;
		int i1;
		i1 = 0l;
		l1 = 0-2147483648;
		l1 = 0-9223372036854775808l;
	}
}