class MiniJavaTest1 {
    public static void main(String[] args) {
        if (a = 3) {

        } else {

        }
    }
}
