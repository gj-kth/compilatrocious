class Main {
	public static void main(String[] args) {
		
	}
}

class I extends Myself {}

class Myself extends Me {}

class Me extends I {}
