//EXT:CEQ

class Test5 {
	
	public static void main(String[] args){
		int a;
		boolean b;
		
		a = 1;
		b = true;
		
		if(a == b){
			System.out.println(0);
		}
		else{
			System.out.println(1);
		}
	}
	
}

