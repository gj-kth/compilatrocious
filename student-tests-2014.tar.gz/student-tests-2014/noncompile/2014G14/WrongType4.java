class WrongType4 {
    public static void main(String[] args) {
        Main m;
        m = new Main();
        m = 3;
    }
}
