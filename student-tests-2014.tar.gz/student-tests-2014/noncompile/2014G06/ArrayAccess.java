class ArrayAccess {
	public static void main(String[] args) {
		int[] arr;
		int i;

		i[0] = arr[i];
	}
}
