class Negative {
  public static void main(String[] args) {
    int a;
    int b;
    a = -5;
    a = 5 + 6 * 4 - (-5);
  }
}
